# Optimus — Minecraft Korku Modu (Fabric)

İki klasör var, ikisi de **aynı Java kodunu** paylaşıyor:

- `optimus-1.21.11/` — senin oynadığın sürüm, öncelikli olan bu
- `optimus-26.2/` — güncel sürüm

Tek kod farkı `ModEntityModelLayers.java` içindeki bir satır (Fabric API o sınıfı 26.x'te yeniden adlandırdı).

---

## Optimus ne yapar

Uzun boylu, **kolsuz**, karanlık bir figür. Ana mekanik: **ona baktığın sürece hareket etmez.** Gözünü ondan ayırdığın anda hızla yaklaşır. Ondan kaçamazsın, sadece bakabilirsin.

Ateşten etkilenmez, itilemez, ok hasarının %25'ini alır, vurulduğunda %30 ihtimalle ışınlanır.

Arka planda her oyuncu için bir **korku (dread) sayacı** işler:

| Korku | Olay |
|---|---|
| 1+ | Uzaktan fısıltı sesleri, ekranda kısa mesajlar |
| 2+ | Etraftaki meşale / fener / kamp ateşi söner |
| 3+ | Zemin bozulur (obsidyen, sculk, soul sand), tuhaf dikilitaşlar belirir |
| 4+ | Karanlıkta 16-30 blok uzakta belirip kaybolan hayaletler |
| 5+ | Envanterden eşya kaybolur |
| 6+ | **Gerçek av** — Optimus saldırmaya gelir |

Yakınındayken Darkness efekti ve kalp atışı sesi alırsın.

---

## Önemli: mappings değişti

Kod artık **Yarn değil, resmi Mojang isimlendirmesi** kullanıyor. Bunun sebebi Fabric'in kendi tavsiyesi: Yarn 1.21.11'den sonrası için güncellenmiyor, çünkü 26.1'den itibaren Minecraft obfuscate edilmiyor. Bu sayede aynı kod iki sürümde de çalışabiliyor.

Yani `World` yerine `Level`, `getWorld()` yerine `level()`, `Text` yerine `Component` göreceksin. Eski 1.21.4 projesindeki isimlerle karıştırma.

---

## Derleme

### En garantili yol (tavsiye ederim)

1. <https://fabricmc.net/develop/template/> adresinden hedef sürüm için boş bir şablon üret
2. Şablonu aç, `src/` klasörünü sil
3. Buradaki klasörün `src/` klasörünü şablona kopyala
4. `fabric.mod.json` içindeki `id`, `entrypoints` alanlarını buradakiyle eşle

Bu yol build dosyalarının kesinlikle doğru olmasını garantiler.

### Doğrudan yol

```bash
gradle wrapper --gradle-version 8.11   # wrapper yoksa
./gradlew runClient
./gradlew build                         # jar -> build/libs/
```

**1.21.11** için `gradle.properties` gerçek değerlerle dolu (Loader 0.19.3, Fabric API 0.141.3+1.21.11, Loom 1.14, Java 21). Yine de fabricmc.net/develop'tan güncel olup olmadığına bak.

**26.2** için değerleri `REPLACE_ME` bıraktım — uydurmak yerine boş bırakmayı tercih ettim. Bunları fabricmc.net/develop'tan doldurman gerekiyor. Ayrıca 26.x obfuscate edilmemiş sürüm olduğu için Loom'un farklı bir varyantını isteyebilir; bu yüzden 26.2 tarafında şablon üretici yolunu kullanmanı özellikle tavsiye ederim.

---

## Derlemede hata alırsan: kontrol listesi

Kodu Fabric'in resmi 1.21.11 ve 26.2 dokümantasyonundaki örneklere göre yazdım, ama derleyip test edemedim. Hata çıkarsa büyük ihtimalle şu birkaç isimden biridir — hepsi IDE'de tek tıkla düzelen şeyler:

| Kodda | Çözülmezse dene |
|---|---|
| `Identifier` (`net.minecraft.resources`) | `ResourceLocation` — aynı sınıf, muhtemel yeniden adlandırma. Proje geneli find/replace yeter. |
| `EntityRenderers.register(...)` | `EntityRendererRegistry.register(...)` (Fabric API karşılığı) |
| `hurtServer(ServerLevel, DamageSource, float)` | `hurt(DamageSource, float)` |
| `EntitySpawnReason.EVENT` | `MobSpawnType.EVENT` |
| `SoundEvents.WARDEN_HEARTBEAT` vb. | Ctrl+Space ile doğru sabiti bul; `ENTITY_` öneki geri gelmiş olabilir |
| `ModelLayerRegistry` / `EntityModelLayerRegistry` | İkisini de dene, sürüme göre biri tutar |

Bunlar sunucu mantığını (korku sistemi, dünya bozma, komutlar) etkilemez — hepsi izole tek satırlık düzeltmeler.

---

## Ayarlar

İlk açılışta `config/optimus.properties` oluşur:

```properties
event_interval_seconds=90   # olaylar arası ortalama süre
world_corruption=true       # blok değiştirme / dikilitaş
steal_items=true            # envanterden eşya çalma
kill_lights=true            # ışıkları söndürme
peaceful_mode=false         # true = sadece gözükür, saldırmaz
hunt_threshold=6            # kaçıncı olaydan sonra avlamaya başlasın
```

Oyun içinde `/optimus reload` ile yeniden yükle.

## Komutlar (OP gerekli)

| Komut | İşlev |
|---|---|
| `/optimus summon` | Saldırgan Optimus çağırır |
| `/optimus clear` | Yakındaki tüm Optimus'ları siler |
| `/optimus dread <0-200>` | Korku seviyesini elle ayarlar |
| `/optimus reset` | Tüm oyuncuların korkusunu sıfırlar |
| `/optimus reload` | Config'i yeniden yükler |

## Dokular

```bash
python3 tools/make_textures.py
```

Model 64x64 doku kullanıyor. UV yerleşimi: kafa (0,0), gövde (0,16), sağ bacak (32,0), sol bacak (32,32). Blockbench'te açacaksan **Mojang mappings** seç, yoksa üreteceği kod bu projeyle uyuşmaz.

## Lisans

MIT
