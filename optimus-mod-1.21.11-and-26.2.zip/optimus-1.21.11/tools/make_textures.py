"""
Optimus icin entity dokularini uretir.
Calistir: python3 tools/make_textures.py
"""
import os
import random

from PIL import Image, ImageDraw

random.seed(20260725)

OUT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "src", "main", "resources", "assets", "optimus"
)
ENTITY_DIR = os.path.join(OUT, "textures", "entity")
os.makedirs(ENTITY_DIR, exist_ok=True)

W = H = 64

# --- kutu bolgeleri (modeldeki uv degerleriyle birebir ayni olmali) ---
def box_region(u, v, w, h, d):
    """Bir cuboid'in dokuda kapladigi dikdortgen."""
    return (u, v, u + 2 * (w + d), v + d + h)

HEAD = box_region(0, 0, 6, 8, 6)        # (0,0)-(24,14)
BODY = box_region(0, 16, 8, 20, 4)      # (0,16)-(24,40)
RLEG = box_region(32, 0, 3, 24, 3)      # (32,0)-(44,27)
LLEG = box_region(32, 32, 3, 24, 3)     # (32,32)-(44,59)

# Kafanin on yuzu: u+d, v+d, genislik w, yukseklik h
FACE = (0 + 6, 0 + 6, 6, 8)             # x=6,y=6, 6x8

BASE = (11, 11, 15)
BODY_TONE = (14, 13, 19)
LEG_TONE = (8, 8, 12)


def fill_noisy(draw, region, tone, jitter=6):
    x0, y0, x1, y1 = region
    for y in range(y0, y1):
        for x in range(x0, x1):
            j = random.randint(-jitter, jitter)
            draw.point((x, y), fill=(
                max(0, min(255, tone[0] + j)),
                max(0, min(255, tone[1] + j)),
                max(0, min(255, tone[2] + j)),
                255
            ))


def eye_pixels():
    """Yuzdeki goz pikselleri (mutlak koordinat listesi)."""
    fx, fy, fw, fh = FACE
    pts = []
    # iki dar, dikey yarik goz
    for dy in (2, 3):
        pts.append((fx + 1, fy + dy))
        pts.append((fx + 4, fy + dy))
    # hafif alt parlama
    pts.append((fx + 1, fy + 4))
    pts.append((fx + 4, fy + 4))
    return pts


def build_main():
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    fill_noisy(d, HEAD, BASE)
    fill_noisy(d, BODY, BODY_TONE)
    fill_noisy(d, RLEG, LEG_TONE)
    fill_noisy(d, LLEG, LEG_TONE)

    # govdenin on yuzunde soluk bir kaburga/gogus izi
    bx, by = 0 + 4, 16 + 4          # body front face
    for i in range(6):
        y = by + 3 + i * 2
        d.point((bx + 3, y), fill=(30, 28, 36, 255))
        d.point((bx + 4, y), fill=(30, 28, 36, 255))

    # omuz hizasinda kol yok - kesik izi
    for x in range(bx, bx + 8):
        d.point((x, by + 1), fill=(24, 6, 8, 255))

    for p in eye_pixels():
        d.point(p, fill=(228, 236, 255, 255))

    img.save(os.path.join(ENTITY_DIR, "optimus.png"))


def _unused_build_eyes():
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for p in eye_pixels():
        d.point(p, fill=(198, 226, 255, 255))
    img.save(os.path.join(ENTITY_DIR, "optimus_eyes.png"))


def build_icon():
    size = 128
    img = Image.new("RGBA", (size, size), (7, 7, 10, 255))
    d = ImageDraw.Draw(img)
    for _ in range(1400):
        x, y = random.randint(0, size - 1), random.randint(0, size - 1)
        v = random.randint(10, 26)
        d.point((x, y), fill=(v, v, v + 4, 255))

    # uzun kolsuz silüet
    d.rectangle([56, 18, 72, 40], fill=(2, 2, 4, 255))       # kafa
    d.rectangle([50, 40, 78, 92], fill=(2, 2, 4, 255))       # govde
    d.rectangle([56, 92, 62, 122], fill=(2, 2, 4, 255))      # bacak
    d.rectangle([66, 92, 72, 122], fill=(2, 2, 4, 255))      # bacak
    d.rectangle([59, 26, 62, 30], fill=(205, 230, 255, 255))
    d.rectangle([66, 26, 69, 30], fill=(205, 230, 255, 255))

    img.save(os.path.join(OUT, "icon.png"))


if __name__ == "__main__":
    build_main()
    build_icon()
    print("Dokular uretildi:", ENTITY_DIR)
