package net.optimus.world;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.optimus.OptimusConfig;
import net.optimus.entity.ModEntityTypes;
import net.optimus.entity.OptimusEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Her oyuncu icin bir "dread" (korku) sayaci tutar ve zamanla artan siddette
 * olaylar tetikler. Sayac arttikca olaylar kotulesir ve sonunda Optimus
 * gercekten avlamaya baslar.
 */
public final class StalkerManager {

	private static final Map<UUID, PlayerState> STATES = new HashMap<>();

	private static final String[] WHISPERS = {
			"seni goruyorum",
			"arkani donme",
			"burasi artik benim",
			"neden hala kacmiyorsun",
			"cok yaklastim",
			"o ses ben degildim"
	};

	private static final Block[] CORRUPTION = {
			Blocks.OBSIDIAN,
			Blocks.SCULK,
			Blocks.SOUL_SAND,
			Blocks.BLACKSTONE,
			Blocks.CRYING_OBSIDIAN,
			Blocks.BLACK_CONCRETE
	};

	private StalkerManager() {
	}

	public static void register() {
		ServerTickEvents.END_WORLD_TICK.register(StalkerManager::tickLevel);
	}

	public static void resetAll() {
		STATES.clear();
	}

	public static int getDread(ServerPlayer player) {
		return state(player).dread;
	}

	public static void setDread(ServerPlayer player, int value) {
		state(player).dread = Math.max(0, value);
	}

	private static PlayerState state(ServerPlayer player) {
		return STATES.computeIfAbsent(player.getUUID(), uuid -> new PlayerState());
	}

	// ------------------------------------------------------------------

	private static void tickLevel(ServerLevel level) {
		if (level.getGameTime() % 20 != 0) {
			return;
		}

		List<ServerPlayer> players = new ArrayList<>(level.players());
		if (players.isEmpty()) {
			return;
		}

		RandomSource random = level.getRandom();

		for (ServerPlayer player : players) {
			if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
				continue;
			}

			PlayerState st = state(player);
			st.cooldownSeconds--;
			if (st.cooldownSeconds > 0) {
				continue;
			}

			st.dread++;
			int base = Math.max(20, OptimusConfig.eventIntervalSeconds);
			// Korku arttikca bekleme suresi kisalir (en az %35'ine kadar).
			double factor = Math.max(0.35, 1.0 - st.dread * 0.05);
			st.cooldownSeconds = (int) (base * factor * (0.6 + random.nextDouble() * 0.8));

			runEvent(level, player, random, st);
		}
	}

	private static void runEvent(ServerLevel level, ServerPlayer player, RandomSource random, PlayerState st) {
		boolean dark = level.getMaxLocalRawBrightness(player.blockPosition()) < 8;
		boolean night = !level.isDay();
		int dread = st.dread;

		List<Runnable> pool = new ArrayList<>();

		// Hafif olaylar - her zaman mumkun
		pool.add(() -> whisper(level, player, random));
		pool.add(() -> whisper(level, player, random));
		pool.add(() -> message(player, random));

		if (OptimusConfig.killLights && dread >= 2) {
			pool.add(() -> lightsOut(level, player));
		}
		if (OptimusConfig.worldCorruption && dread >= 3) {
			pool.add(() -> corruptGround(level, player, random));
			pool.add(() -> monolith(level, player, random));
		}
		if (OptimusConfig.stealItems && dread >= 5) {
			pool.add(() -> stealItem(level, player, random));
		}
		if (dread >= 4 && (dark || night)) {
			pool.add(() -> apparition(level, player, random));
			pool.add(() -> apparition(level, player, random));
		}
		if (!OptimusConfig.peacefulMode && dread >= OptimusConfig.huntThreshold) {
			pool.add(() -> hunt(level, player, random));
		}

		pool.get(random.nextInt(pool.size())).run();
	}

	// ------------------------------------------------------------------
	// Olaylar
	// ------------------------------------------------------------------

	private static void whisper(ServerLevel level, ServerPlayer player, RandomSource random) {
		double angle = random.nextDouble() * Math.PI * 2;
		double dist = 6 + random.nextDouble() * 10;
		double x = player.getX() + Math.cos(angle) * dist;
		double z = player.getZ() + Math.sin(angle) * dist;

		level.playSound(null, x, player.getY(), z,
				random.nextBoolean() ? SoundEvents.SCULK_SHRIEKER_SHRIEK : SoundEvents.ENDERMAN_STARE,
				SoundSource.AMBIENT, 0.8f, 0.4f + random.nextFloat() * 0.2f);
	}

	private static void message(ServerPlayer player, RandomSource random) {
		String text = WHISPERS[random.nextInt(WHISPERS.length)];
		player.displayClientMessage(
				Component.literal(text).withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), true);
	}

	/** Etraftaki isik kaynaklarini sondurur. */
	private static void lightsOut(ServerLevel level, ServerPlayer player) {
		BlockPos center = player.blockPosition();
		int removed = 0;

		for (BlockPos pos : BlockPos.betweenClosed(center.offset(-10, -6, -10), center.offset(10, 6, 10))) {
			BlockState state = level.getBlockState(pos);
			if (state.is(BlockTags.CANDLES)
					|| state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH)
					|| state.is(Blocks.SOUL_TORCH) || state.is(Blocks.SOUL_WALL_TORCH)
					|| state.is(Blocks.LANTERN) || state.is(Blocks.SOUL_LANTERN)
					|| state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE)
					|| state.is(Blocks.GLOWSTONE) || state.is(Blocks.SEA_LANTERN)) {

				level.setBlock(pos.immutable(), Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
				level.sendParticles(ParticleTypes.SMOKE,
						pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
						8, 0.1, 0.1, 0.1, 0.01);
				removed++;
				if (removed >= 24) {
					break;
				}
			}
		}

		if (removed > 0) {
			level.playSound(null, center, SoundEvents.FIRE_EXTINGUISH,
					SoundSource.AMBIENT, 1.0f, 0.4f);
		}
	}

	/** Yerdeki bloklari bozar. */
	private static void corruptGround(ServerLevel level, ServerPlayer player, RandomSource random) {
		int patches = 8 + random.nextInt(10);

		for (int i = 0; i < patches; i++) {
			int x = Mth.floor(player.getX()) + random.nextInt(17) - 8;
			int z = Mth.floor(player.getZ()) + random.nextInt(17) - 8;

			if (!level.hasChunk(x >> 4, z >> 4)) {
				continue;
			}

			int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
			BlockPos pos = new BlockPos(x, y, z);
			if (!canReplace(level, pos)) {
				continue;
			}

			level.setBlock(pos, CORRUPTION[random.nextInt(CORRUPTION.length)].defaultBlockState(),
					Block.UPDATE_ALL);
		}

		level.playSound(null, player.blockPosition(), SoundEvents.SCULK_BLOCK_SPREAD,
				SoundSource.AMBIENT, 1.0f, 0.5f);
	}

	/** Oyuncunun yakinina tuhaf bir dikilitas insa eder. */
	private static void monolith(ServerLevel level, ServerPlayer player, RandomSource random) {
		BlockPos base = findSurface(level, player, random, 8, 18);
		if (base == null) {
			return;
		}

		int height = 4 + random.nextInt(4);
		for (int y = 0; y < height; y++) {
			BlockPos pos = base.above(y);
			BlockState existing = level.getBlockState(pos);
			if (!existing.isAir() && !existing.canBeReplaced()) {
				break;
			}
			level.setBlock(pos, Blocks.OBSIDIAN.defaultBlockState(), Block.UPDATE_ALL);
		}

		BlockPos top = base.above(height);
		if (level.getBlockState(top).isAir()) {
			level.setBlock(top, Blocks.SCULK_SHRIEKER.defaultBlockState(), Block.UPDATE_ALL);
		}

		level.playSound(null, base, SoundEvents.SCULK_SHRIEKER_SHRIEK,
				SoundSource.AMBIENT, 0.8f, 0.4f);
	}

	/** Envanterden rastgele bir esya alir. */
	private static void stealItem(ServerLevel level, ServerPlayer player, RandomSource random) {
		List<Integer> filled = new ArrayList<>();
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			if (!player.getInventory().getItem(i).isEmpty()) {
				filled.add(i);
			}
		}
		if (filled.isEmpty()) {
			return;
		}

		int slot = filled.get(random.nextInt(filled.size()));
		ItemStack stack = player.getInventory().getItem(slot);
		int take = Math.max(1, Math.min(stack.getCount(), 1 + random.nextInt(3)));
		player.getInventory().removeItem(slot, take);

		player.displayClientMessage(
				Component.literal("bir seyler eksik...")
						.withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC), true);
		level.playSound(null, player.blockPosition(), SoundEvents.ITEM_PICKUP,
				SoundSource.AMBIENT, 0.6f, 0.3f);
	}

	/** Uzakta kisa sureligine belirip kaybolan hayalet. */
	private static void apparition(ServerLevel level, ServerPlayer player, RandomSource random) {
		spawn(level, player, random, 16, 30, true, 12);
	}

	/** Gercek av: saldirmak icin gelir. */
	private static void hunt(ServerLevel level, ServerPlayer player, RandomSource random) {
		boolean alreadyHunting = !level.getEntitiesOfClass(OptimusEntity.class,
				player.getBoundingBox().inflate(64.0), e -> !e.isApparition()).isEmpty();
		if (alreadyHunting) {
			return;
		}

		OptimusEntity optimus = spawn(level, player, random, 20, 34, false, 60 * 5);
		if (optimus == null) {
			return;
		}

		optimus.setTarget(player);
		player.displayClientMessage(
				Component.literal("O geliyor.").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
		level.playSound(null, player.blockPosition(), SoundEvents.WARDEN_NEARBY_CLOSEST,
				SoundSource.HOSTILE, 1.0f, 0.5f);
	}

	private static OptimusEntity spawn(ServerLevel level, ServerPlayer player, RandomSource random,
	                                   int min, int max, boolean apparition, int lifeSeconds) {
		BlockPos pos = findSurface(level, player, random, min, max);
		if (pos == null) {
			return null;
		}

		OptimusEntity optimus = ModEntityTypes.OPTIMUS.create(level, EntitySpawnReason.EVENT);
		if (optimus == null) {
			return null;
		}

		optimus.setApparition(apparition, lifeSeconds);
		optimus.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, lookAtYaw(pos, player), 0.0f);
		optimus.setPersistenceRequired();
		level.addFreshEntity(optimus);
		return optimus;
	}

	// ------------------------------------------------------------------
	// Yardimcilar
	// ------------------------------------------------------------------

	private static boolean canReplace(ServerLevel level, BlockPos pos) {
		BlockState state = level.getBlockState(pos);
		if (state.isAir() || state.hasBlockEntity()) {
			return false;
		}
		// Kirilamaz bloklara (bedrock vb.) dokunma.
		return state.getDestroySpeed(level, pos) >= 0;
	}

	private static float lookAtYaw(BlockPos from, ServerPlayer target) {
		double dx = target.getX() - (from.getX() + 0.5);
		double dz = target.getZ() - (from.getZ() + 0.5);
		return (float) (Mth.atan2(dz, dx) * 57.2957795 - 90.0);
	}

	/**
	 * Oyuncunun etrafinda min-max mesafede, uzerinde 4 blok bosluk olan bir zemin bulur.
	 */
	private static BlockPos findSurface(ServerLevel level, ServerPlayer player, RandomSource random,
	                                    int min, int max) {
		for (int attempt = 0; attempt < 24; attempt++) {
			double angle = random.nextDouble() * Math.PI * 2;
			double dist = min + random.nextDouble() * (max - min);
			int x = Mth.floor(player.getX() + Math.cos(angle) * dist);
			int z = Mth.floor(player.getZ() + Math.sin(angle) * dist);

			if (!level.hasChunk(x >> 4, z >> 4)) {
				continue;
			}

			int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);

			// Yeraltindaysan yuzeye degil, kendi seviyene yakin bir yer ara.
			if (Math.abs(y - player.getY()) > 12) {
				BlockPos scan = new BlockPos(x, Mth.floor(player.getY()), z);
				for (int dy = 0; dy <= 6; dy++) {
					if (isValidStand(level, scan.below(dy))) {
						return scan.below(dy);
					}
				}
				continue;
			}

			BlockPos pos = new BlockPos(x, y, z);
			if (isValidStand(level, pos)) {
				return pos;
			}
		}
		return null;
	}

	private static boolean isValidStand(ServerLevel level, BlockPos pos) {
		BlockPos below = pos.below();
		if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
			return false;
		}
		for (int i = 0; i < 4; i++) {
			if (!level.getBlockState(pos.above(i)).isAir()) {
				return false;
			}
		}
		return true;
	}

	private static final class PlayerState {
		int dread = 0;
		int cooldownSeconds = 60;
	}
}
