package net.optimus.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.optimus.entity.ModEntityTypes;

public class OptimusClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		ModEntityModelLayers.register();
		// Cozulmezse Fabric API karsiligi: EntityRendererRegistry.register(...)
		EntityRenderers.register(ModEntityTypes.OPTIMUS, OptimusRenderer::new);
	}
}
