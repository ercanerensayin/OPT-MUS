package net.optimus.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.optimus.OptimusMod;
import net.optimus.entity.OptimusEntity;

public class OptimusRenderer extends MobRenderer<OptimusEntity, OptimusRenderState, OptimusModel> {

	private static final Identifier TEXTURE = OptimusMod.id("textures/entity/optimus.png");

	public OptimusRenderer(EntityRendererProvider.Context context) {
		super(context, new OptimusModel(context.bakeLayer(ModEntityModelLayers.OPTIMUS)), 0.6f);
	}

	@Override
	public OptimusRenderState createRenderState() {
		return new OptimusRenderState();
	}

	@Override
	public void extractRenderState(OptimusEntity entity, OptimusRenderState state, float tickProgress) {
		super.extractRenderState(entity, state, tickProgress);
		state.observed = entity.isObserved();
	}

	@Override
	public Identifier getTextureLocation(OptimusRenderState state) {
		return TEXTURE;
	}
}
