package net.optimus.client;

import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.optimus.OptimusMod;

/**
 * DIKKAT: Bu dosya iki surum arasinda farkli olan TEK dosya.
 *
 *  - 1.21.11 -> EntityModelLayerRegistry.registerModelLayer(...)
 *  - 26.2    -> ModelLayerRegistry.registerModelLayer(...)   (Fabric API'de yeniden adlandirildi)
 */
public final class ModEntityModelLayers {

	public static final ModelLayerLocation OPTIMUS =
			new ModelLayerLocation(OptimusMod.id("optimus"), "main");

	private ModEntityModelLayers() {
	}

	public static void register() {
		EntityModelLayerRegistry.registerModelLayer(OPTIMUS, OptimusModel::createBodyLayer);
	}
}
