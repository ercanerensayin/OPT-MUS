package net.optimus.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class OptimusRenderState extends LivingEntityRenderState {
	public boolean observed;
}
