package net.optimus.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Uzun boylu, KOLSUZ figur.
 *
 * Model koordinatlari: y buyudukce ASAGI gider (oyun icinin tersi).
 * Ayaklar y=24, kalca y=0, kafanin tepesi y=-28. Toplam 52px = ~3.25 blok.
 */
public class OptimusModel extends EntityModel<OptimusRenderState> {

	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;

	public OptimusModel(ModelPart root) {
		super(root);
		this.head = root.getChild("head");
		this.body = root.getChild("body");
		this.rightLeg = root.getChild("right_leg");
		this.leftLeg = root.getChild("left_leg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		root.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-3.0f, -8.0f, -3.0f, 6.0f, 8.0f, 6.0f),
				PartPose.offset(0.0f, -20.0f, 0.0f));

		root.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 16)
						.addBox(-4.0f, -20.0f, -2.0f, 8.0f, 20.0f, 4.0f),
				PartPose.offset(0.0f, 0.0f, 0.0f));

		root.addOrReplaceChild("right_leg",
				CubeListBuilder.create().texOffs(32, 0)
						.addBox(-1.5f, 0.0f, -1.5f, 3.0f, 24.0f, 3.0f),
				PartPose.offset(-2.2f, 0.0f, 0.0f));

		root.addOrReplaceChild("left_leg",
				CubeListBuilder.create().texOffs(32, 32)
						.addBox(-1.5f, 0.0f, -1.5f, 3.0f, 24.0f, 3.0f),
				PartPose.offset(2.2f, 0.0f, 0.0f));

		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(OptimusRenderState state) {
		super.setupAnim(state);

		// Kafa oyuncuyu takip eder.
		this.head.yRot = state.yRot * Mth.DEG_TO_RAD;
		this.head.xRot = state.xRot * Mth.DEG_TO_RAD;

		if (state.observed) {
			// Bakildiginda tamamen donar. Hicbir animasyon yok - en rahatsiz edici hali.
			this.rightLeg.xRot = 0.0f;
			this.leftLeg.xRot = 0.0f;
			this.body.xRot = 0.0f;
			this.head.zRot = 0.18f; // kafa hafifce yana egilir
			return;
		}

		this.head.zRot = 0.0f;

		// Uzun bacakli, yavas ve genis adim.
		float swing = state.walkAnimationPos * 0.5f;
		float amount = Math.min(state.walkAnimationSpeed, 1.0f);
		this.rightLeg.xRot = Mth.cos(swing) * 1.1f * amount;
		this.leftLeg.xRot = Mth.cos(swing + Mth.PI) * 1.1f * amount;

		// Hafif one egilmis govde + nefes alir gibi salinim.
		this.body.xRot = 0.10f + Mth.sin(state.ageInTicks * 0.05f) * 0.02f;
	}
}
