package net.optimus;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import net.optimus.command.OptimusCommand;
import net.optimus.entity.ModEntityTypes;
import net.optimus.world.StalkerManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OptimusMod implements ModInitializer {

	public static final String MOD_ID = "optimus";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		OptimusConfig.load();
		ModEntityTypes.registerAttributes();
		StalkerManager.register();
		OptimusCommand.register();
		LOGGER.info("Optimus uyandi.");
	}
}
