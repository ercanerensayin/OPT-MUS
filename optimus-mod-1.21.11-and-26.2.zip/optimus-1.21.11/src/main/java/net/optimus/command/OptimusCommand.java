package net.optimus.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.optimus.OptimusConfig;
import net.optimus.entity.ModEntityTypes;
import net.optimus.entity.OptimusEntity;
import net.optimus.world.StalkerManager;

public final class OptimusCommand {

	private OptimusCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(Commands.literal("optimus")
						.requires(source -> source.hasPermission(2))

						.then(Commands.literal("summon").executes(ctx -> {
							CommandSourceStack source = ctx.getSource();
							ServerPlayer player = source.getPlayerOrException();
							ServerLevel level = source.getLevel();

							OptimusEntity optimus = ModEntityTypes.OPTIMUS.create(level, EntitySpawnReason.COMMAND);
							if (optimus == null) {
								return 0;
							}
							optimus.setApparition(false, 60 * 10);
							optimus.moveTo(player.getX(), player.getY(), player.getZ(), player.getYRot(), 0.0f);
							optimus.setPersistenceRequired();
							optimus.setTarget(player);
							level.addFreshEntity(optimus);

							source.sendSuccess(() -> Component.literal("Optimus cagrildi."), false);
							return 1;
						}))

						.then(Commands.literal("clear").executes(ctx -> {
							CommandSourceStack source = ctx.getSource();
							ServerPlayer player = source.getPlayerOrException();
							int count = 0;
							for (OptimusEntity e : source.getLevel().getEntitiesOfClass(
									OptimusEntity.class, player.getBoundingBox().inflate(256.0), e -> true)) {
								e.discard();
								count++;
							}
							final int removed = count;
							source.sendSuccess(() -> Component.literal(removed + " Optimus silindi."), false);
							return removed;
						}))

						.then(Commands.literal("dread")
								.then(Commands.argument("amount", IntegerArgumentType.integer(0, 200))
										.executes(ctx -> {
											int amount = IntegerArgumentType.getInteger(ctx, "amount");
											StalkerManager.setDread(ctx.getSource().getPlayerOrException(), amount);
											ctx.getSource().sendSuccess(
													() -> Component.literal("Korku seviyesi: " + amount), false);
											return amount;
										})))

						.then(Commands.literal("reset").executes(ctx -> {
							StalkerManager.resetAll();
							ctx.getSource().sendSuccess(() -> Component.literal("Sifirlandi."), false);
							return 1;
						}))

						.then(Commands.literal("reload").executes(ctx -> {
							OptimusConfig.load();
							ctx.getSource().sendSuccess(() -> Component.literal("Config yeniden yuklendi."), false);
							return 1;
						}))
				));
	}
}
