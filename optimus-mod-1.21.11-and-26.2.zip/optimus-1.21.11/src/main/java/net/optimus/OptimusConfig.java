package net.optimus;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * config/optimus.properties dosyasindan okunur. Dosya yoksa varsayilanlarla olusturulur.
 */
public final class OptimusConfig {

	/** Olaylar arasi ortalama sure (saniye). Kucultursen mod daha agresif olur. */
	public static int eventIntervalSeconds = 90;

	/** Optimus'un dunyaya blok koyup/degistirmesine izin ver. */
	public static boolean worldCorruption = true;

	/** Envanterden esya calabilsin mi. */
	public static boolean stealItems = true;

	/** Isiklari (mesale, fener, kamp atesi) sondurebilsin mi. */
	public static boolean killLights = true;

	/** Sadece hayalet olarak gorunsun, gercekten saldirmasin. */
	public static boolean peacefulMode = false;

	/** Kac olaydan sonra gercekten avlamaya baslasin. */
	public static int huntThreshold = 6;

	private OptimusConfig() {
	}

	public static void load() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("optimus.properties");
		Properties props = new Properties();

		if (Files.exists(file)) {
			try (InputStream in = Files.newInputStream(file)) {
				props.load(in);
			} catch (IOException e) {
				OptimusMod.LOGGER.warn("Config okunamadi, varsayilanlar kullanilacak.", e);
			}

			eventIntervalSeconds = getInt(props, "event_interval_seconds", eventIntervalSeconds);
			worldCorruption = getBool(props, "world_corruption", worldCorruption);
			stealItems = getBool(props, "steal_items", stealItems);
			killLights = getBool(props, "kill_lights", killLights);
			peacefulMode = getBool(props, "peaceful_mode", peacefulMode);
			huntThreshold = getInt(props, "hunt_threshold", huntThreshold);
		}

		save(file);
	}

	private static void save(Path file) {
		Properties props = new Properties();
		props.setProperty("event_interval_seconds", String.valueOf(eventIntervalSeconds));
		props.setProperty("world_corruption", String.valueOf(worldCorruption));
		props.setProperty("steal_items", String.valueOf(stealItems));
		props.setProperty("kill_lights", String.valueOf(killLights));
		props.setProperty("peaceful_mode", String.valueOf(peacefulMode));
		props.setProperty("hunt_threshold", String.valueOf(huntThreshold));

		try {
			Files.createDirectories(file.getParent());
			try (OutputStream out = Files.newOutputStream(file)) {
				props.store(out, "Optimus mod ayarlari");
			}
		} catch (IOException e) {
			OptimusMod.LOGGER.warn("Config yazilamadi.", e);
		}
	}

	private static int getInt(Properties p, String key, int def) {
		try {
			return Integer.parseInt(p.getProperty(key, String.valueOf(def)).trim());
		} catch (NumberFormatException e) {
			return def;
		}
	}

	private static boolean getBool(Properties p, String key, boolean def) {
		return Boolean.parseBoolean(p.getProperty(key, String.valueOf(def)).trim());
	}
}
