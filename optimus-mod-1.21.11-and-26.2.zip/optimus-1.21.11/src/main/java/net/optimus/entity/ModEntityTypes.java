package net.optimus.entity;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.optimus.OptimusMod;

public final class ModEntityTypes {

	public static final ResourceKey<EntityType<?>> OPTIMUS_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, OptimusMod.id("optimus"));

	public static final EntityType<OptimusEntity> OPTIMUS = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			OPTIMUS_KEY,
			EntityType.Builder.<OptimusEntity>of(OptimusEntity::new, MobCategory.MONSTER)
					.sized(0.9f, 3.3f)
					.eyeHeight(3.05f)
					.clientTrackingRange(16)
					.updateInterval(2)
					.build(OPTIMUS_KEY)
	);

	private ModEntityTypes() {
	}

	public static void registerAttributes() {
		FabricDefaultAttributeRegistry.register(OPTIMUS, OptimusEntity.createOptimusAttributes());
	}
}
