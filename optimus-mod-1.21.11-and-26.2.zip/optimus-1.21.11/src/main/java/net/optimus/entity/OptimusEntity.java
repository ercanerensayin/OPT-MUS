package net.optimus.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.optimus.OptimusConfig;

/**
 * Optimus: uzun boylu, kolsuz, karanlik bir figur.
 *
 * Temel mekanik: BAKILDIGI SURECE HAREKET ETMEZ. Gozunu ondan ayirdigin
 * anda hizla yaklasir. Yani ondan kacamazsin, sadece bakabilirsin.
 */
public class OptimusEntity extends Monster {

	private static final EntityDataAccessor<Boolean> OBSERVED =
			SynchedEntityData.defineId(OptimusEntity.class, EntityDataSerializers.BOOLEAN);

	/** Hayalet modu: sadece bakar, saldirmaz, kisa surede yok olur. */
	private boolean apparition = false;
	private int lifeTicks = 0;
	private int maxLifeTicks = Integer.MAX_VALUE;

	public OptimusEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
		this.xpReward = 40;
	}

	public static AttributeSupplier.Builder createOptimusAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 120.0)
				.add(Attributes.MOVEMENT_SPEED, 0.36)
				.add(Attributes.ATTACK_DAMAGE, 9.0)
				.add(Attributes.ARMOR, 6.0)
				.add(Attributes.FOLLOW_RANGE, 64.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
				.add(Attributes.STEP_HEIGHT, 1.5);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15, true));
		this.goalSelector.addGoal(4, new RandomStrollGoal(this, 0.8));
		this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 64.0f));
		this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(OBSERVED, false);
	}

	public boolean isObserved() {
		return this.entityData.get(OBSERVED);
	}

	public boolean isApparition() {
		return this.apparition;
	}

	public void setApparition(boolean value, int lifeSeconds) {
		this.apparition = value;
		this.maxLifeTicks = lifeSeconds * 20;
		if (value) {
			this.setTarget(null);
		}
	}

	// ------------------------------------------------------------------
	// Ana dongu
	// ------------------------------------------------------------------

	@Override
	public void tick() {
		if (this.level() instanceof ServerLevel server) {
			boolean watched = this.computeWatched();
			this.entityData.set(OBSERVED, watched);

			if (watched || this.apparition) {
				// Bakiliyor: donar kalir.
				this.getNavigation().stop();
				this.setDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
				this.hasImpulse = true;
			}

			this.lifeTicks++;

			if (this.lifeTicks % 60 == 0) {
				this.spreadDread(server);
			}

			if (this.lifeTicks >= this.maxLifeTicks) {
				this.vanish(server);
				return;
			}

			if (this.apparition && server.getNearestPlayer(this, 6.0) != null) {
				this.vanish(server);
				return;
			}
		}

		super.tick();
	}

	/** Herhangi bir oyuncunun gorus alaninda miyim? */
	private boolean computeWatched() {
		for (Player player : this.level().players()) {
			if (player.isSpectator() || !player.isAlive() || player.isCreative()) {
				continue;
			}
			if (player.distanceToSqr(this) > 64.0 * 64.0) {
				continue;
			}

			Vec3 look = player.getLookAngle().normalize();
			Vec3 toMe = new Vec3(
					this.getX() - player.getX(),
					this.getEyeY() - player.getEyeY(),
					this.getZ() - player.getZ()
			);
			double length = toMe.length();
			if (length < 0.5) {
				return true;
			}

			double dot = look.dot(toMe.scale(1.0 / length));
			if (dot > 0.50 && player.hasLineOfSight(this)) {
				return true;
			}
		}
		return false;
	}

	/** Yakindaki oyunculara korku efekti yayar. */
	private void spreadDread(ServerLevel level) {
		for (Player player : level.players()) {
			if (player.isCreative() || player.isSpectator()) {
				continue;
			}
			double dist = player.distanceTo(this);
			if (dist > 32.0) {
				continue;
			}

			if (dist < 18.0) {
				player.addEffect(new MobEffectInstance(
						MobEffects.DARKNESS, 120, 0, false, false, false));
			}

			level.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE,
					(float) Mth.clamp(1.2 - dist / 32.0, 0.15, 1.0),
					0.4f + (float) (dist / 64.0));
		}

		level.sendParticles(ParticleTypes.SMOKE,
				this.getX(), this.getY() + 0.2, this.getZ(),
				6, 0.35, 0.1, 0.35, 0.01);
	}

	public void vanish(ServerLevel level) {
		level.sendParticles(ParticleTypes.LARGE_SMOKE,
				this.getX(), this.getY() + 1.6, this.getZ(),
				40, 0.4, 1.2, 0.4, 0.02);
		level.playSound(null, this.blockPosition(), SoundEvents.ENDERMAN_TELEPORT,
				SoundSource.HOSTILE, 0.7f, 0.4f);
		this.discard();
	}

	/** Kisa mesafe isinlanma. */
	private void blink(ServerLevel level) {
		for (int i = 0; i < 16; i++) {
			double x = this.getX() + (this.random.nextDouble() - 0.5) * 16.0;
			double z = this.getZ() + (this.random.nextDouble() - 0.5) * 16.0;
			double y = this.getY() + (this.random.nextInt(9) - 4);

			if (level.noCollision(this, this.getBoundingBox().move(
					x - this.getX(), y - this.getY(), z - this.getZ()))) {
				level.sendParticles(ParticleTypes.SMOKE, this.getX(), this.getY() + 1.5, this.getZ(),
						30, 0.3, 1.0, 0.3, 0.02);
				this.teleportTo(x, y, z);
				level.playSound(null, this.blockPosition(), SoundEvents.ENDERMAN_TELEPORT,
						SoundSource.HOSTILE, 0.6f, 0.35f);
				return;
			}
		}
	}

	// ------------------------------------------------------------------
	// Hasar / dayaniklilik
	// ------------------------------------------------------------------

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		if (this.apparition) {
			this.vanish(level);
			return false;
		}

		// Uzaktan oldurulemesin diye ok/mermi hasarini ciddi sekilde azaltiriz.
		if (source.is(DamageTypeTags.IS_PROJECTILE)) {
			amount *= 0.25f;
		}
		if (source.is(DamageTypeTags.IS_EXPLOSION)) {
			amount *= 0.5f;
		}

		boolean result = super.hurtServer(level, source, amount);
		if (result && this.random.nextFloat() < 0.30f) {
			this.blink(level);
		}
		return result;
	}

	@Override
	public boolean fireImmune() {
		return true;
	}

	@Override
	public boolean canBeLeashed() {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public boolean removeWhenFarAway(double distanceSquared) {
		return false;
	}

	@Override
	public boolean canUsePortal(boolean allowVehicles) {
		return false;
	}

	// ------------------------------------------------------------------
	// Sesler
	// ------------------------------------------------------------------

	@Override
	protected SoundEvent getAmbientSound() {
		return OptimusConfig.peacefulMode
				? SoundEvents.ENDERMAN_STARE
				: SoundEvents.WARDEN_HEARTBEAT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.WARDEN_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.WARDEN_DEATH;
	}

	@Override
	public int getAmbientSoundInterval() {
		return 120;
	}

	@Override
	protected float getSoundVolume() {
		return 0.9f;
	}
}
